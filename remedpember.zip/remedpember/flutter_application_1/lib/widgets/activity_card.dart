import 'package:flutter/material.dart';
import 'package:flutter_application_1/models/activity.dart'; // Adjust path if needed
import 'package:intl/intl.dart'; // For date formatting

class ActivityCard extends StatelessWidget {
  final Activity activity;
  final VoidCallback onTap;

  const ActivityCard({
    super.key,
    required this.activity,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      color: const Color(0xFF52A7A4), // This is already the color from the first image
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12.0),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12.0),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            children: [
              // You can add an image asset here if you have default images for categories
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8.0),
                  image: activity.documentationImagePath != null
                      ? DecorationImage(
                          image: AssetImage(activity.documentationImagePath!), // Or FileImage if from device
                          fit: BoxFit.cover,
                        )
                      : null, // No image if path is null
                  color: const Color(0xFF52A7A4), // Changed this to match the card background
                ),
                child: activity.documentationImagePath == null
                    ? const Icon(Icons.description, color: Colors.white, size: 30) // Placeholder icon
                    : null,
              ),
              const SizedBox(width: 16.0),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      activity.name,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18.0,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4.0),
                    Text(
                      'Tanggal: ${DateFormat('dd MMMM HH:mm').format(activity.date)}',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.8),
                        fontSize: 14.0,
                      ),
                    ),
                    const SizedBox(height: 4.0),
                    Text(
                      activity.category,
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.8),
                        fontSize: 14.0,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}