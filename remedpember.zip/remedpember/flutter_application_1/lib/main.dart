import 'package:flutter/material.dart';
import 'package:flutter_application_1/screens/daily_activity_screen.dart'; // Adjust path if needed

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Daily Activity App',
      theme: ThemeData(
        primarySwatch: Colors.teal, // You can customize your theme colors
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: DailyActivityScreen(),
    );
  }
}



// NAMA      : MUHAMMAD JAFAR SHIDIQ
// NIM       : 230441100083
// PRAKTIKUM : PEMBER B
// ASPRAK    : KUKUH COKRO