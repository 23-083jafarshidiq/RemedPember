class Activity {
  String name;
  String category;
  DateTime date;
  String description;
  String? documentationImagePath; // Path to the image, can be null

  Activity({
    required this.name,
    required this.category,
    required this.date,
    required this.description,
    this.documentationImagePath,
  });
}