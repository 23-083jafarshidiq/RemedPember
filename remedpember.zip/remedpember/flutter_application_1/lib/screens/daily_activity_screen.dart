import 'package:flutter/material.dart';
import 'package:flutter_application_1/models/activity.dart'; // Adjust path if needed
import 'package:flutter_application_1/widgets/activity_card.dart'; // Adjust path if needed
import 'package:flutter_application_1/screens/add_data_screen.dart'; // Adjust path if needed
import 'package:flutter_application_1/screens/detail_task_screen.dart'; // Adjust path if needed

class DailyActivityScreen extends StatefulWidget {
  const DailyActivityScreen({super.key});

  @override
  State<DailyActivityScreen> createState() => _DailyActivityScreenState();
}

class _DailyActivityScreenState extends State<DailyActivityScreen> {
  // This list will hold your activities. In a real app, this would come from a database.
  List<Activity> _activities = [
    Activity(
      name: 'Mengerjakan Tugas',
      category: 'Kuliah',
      date: DateTime(2025, 5, 27),
      description: 'Mengerjakan tugas matakuliah Flutter',
    ),
    Activity(
      name: 'Pergi Kuliah',
      category: 'Kuliah',
      date: DateTime(2025, 5, 27),
      description: 'Pergi ke kampus untuk kuliah Mobile Programming',
    ),
    Activity(
      name: 'Rapat Akbar',
      category: 'Organisasi',
      date: DateTime(2025, 5, 28),
      description: 'Rapat anggota untuk persiapan event',
    ),
    Activity(
      name: 'Makan',
      category: 'Lainnya',
      date: DateTime(2025, 5, 28),
      description: 'Makan di mawar',
    ),
  ];

  void _addActivity(Activity newActivity) {
    setState(() {
      _activities.add(newActivity);
    });
  }

  void _deleteActivity(Activity activityToDelete) {
    setState(() {
      _activities.remove(activityToDelete);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Daily Activity',
          style: TextStyle(color: Colors.white), // Tambahkan warna teks putih agar terlihat jelas
        ),
        backgroundColor: const Color(0xFF5CA7A4), // Ubah ke warna yang lebih sesuai dengan gambar
      ),
      body: ListView.builder(
        itemCount: _activities.length,
        itemBuilder: (context, index) {
          final activity = _activities[index];
          return ActivityCard(
            activity: activity,
            onTap: () async {
              final result = await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => DetailTaskScreen(activity: activity),
                ),
              );

              if (result == true) {
                // If detail screen indicates deletion
                _deleteActivity(activity);
              }
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final newActivity = await Navigator.push<Activity>(
            context,
            MaterialPageRoute(
              builder: (context) => AddDataScreen(),
            ),
          );
          if (newActivity != null) {
            _addActivity(newActivity);
          }
        },
        backgroundColor: const Color(0xFF5CA7A4), // Ubah ke warna yang lebih sesuai dengan gambar
        child: const Icon(Icons.add, color: Colors.white), // Tambahkan warna ikon putih
      ),
    );
  }
}