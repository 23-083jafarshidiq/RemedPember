import 'package:flutter/material.dart';
import 'package:flutter_application_1/models/activity.dart'; // Adjust path if needed
import 'package:intl/intl.dart'; // For date formatting
import 'package:image_picker/image_picker.dart'; // For picking images
import 'dart:io'; // For File
import 'package:flutter/foundation.dart' show kIsWeb; // Import for platform detection
import 'dart:typed_data'; // For Uint8List, needed for Image.memory

class AddDataScreen extends StatefulWidget {
  const AddDataScreen({super.key});

  @override
  State<AddDataScreen> createState() => _AddDataScreenState();
}

class _AddDataScreenState extends State<AddDataScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  String _selectedCategory = 'Lainnya'; // Default category
  DateTime _selectedDate = DateTime.now();
  
  // Perubahan: Gunakan XFile dari image_picker secara langsung atau Uint8List untuk web
  XFile? _pickedXFile; // Menyimpan XFile untuk akses path atau bytes
  Uint8List? _webImageBytes; // Menyimpan bytes gambar untuk ditampilkan di web

  final List<String> _categories = [
    'Kuliah',
    'Organisasi',
    'Lainnya',
  ];

  Future<void> _pickImage() async {
    final pickedFile = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _pickedXFile = pickedFile; // Simpan XFile
        if (kIsWeb) {
          // Jika di web, baca bytes-nya untuk ditampilkan
          pickedFile.readAsBytes().then((bytes) {
            setState(() {
              _webImageBytes = bytes;
            });
          });
        }
      });
      print('Gambar dipilih dengan path: ${pickedFile.path}'); // Debugging: Cek path yang didapat
    } else {
      print('Tidak ada gambar yang dipilih.');
    }
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2030),
      builder: (BuildContext context, Widget? child) {
        return Theme(
          data: ThemeData.light().copyWith(
            primaryColor: const Color(0xFF5CA7A4), // Warna header date picker
            colorScheme: const ColorScheme.light(primary: Color(0xFF5CA7A4)), // Warna tanggal terpilih
            buttonTheme: const ButtonThemeData(textTheme: ButtonTextTheme.primary),
          ),
          child: child!,
        );
      },
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  void _saveData() {
    if (_formKey.currentState!.validate()) {
      final newActivity = Activity(
        name: _nameController.text,
        category: _selectedCategory,
        date: _selectedDate,
        description: _descriptionController.text,
        documentationImagePath: _pickedXFile?.path, // Tetap simpan path di model
      );
      Navigator.pop(context, newActivity); // Pass the new activity back
    }
  }

  Widget _buildInputField({
    required String label,
    required TextEditingController controller,
    String? hintText,
    bool isMultiLine = false,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 8.0),
          child: Text(
            label,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              color: Color(0xFF5CA7A4), // Warna label teks
            ),
          ),
        ),
        TextFormField(
          controller: controller,
          maxLines: isMultiLine ? 4 : 1,
          decoration: InputDecoration(
            hintText: hintText,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8.0),
              borderSide: const BorderSide(color: Color(0xFF5CA7A4)), // Warna border input field
            ),
            enabledBorder: OutlineInputBorder( // Menambahkan enabledBorder
              borderRadius: BorderRadius.circular(8.0),
              borderSide: const BorderSide(color: Color(0xFF5CA7A4)),
            ),
            focusedBorder: OutlineInputBorder( // Menambahkan focusedBorder
              borderRadius: BorderRadius.circular(8.0),
              borderSide: const BorderSide(color: Color(0xFF5CA7A4), width: 2.0),
            ),
            filled: true,
            fillColor: Colors.grey.shade100, // Warna latar belakang input field
          ),
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'Please enter $label';
            }
            return null;
          },
        ),
        const SizedBox(height: 16.0),
      ],
    );
  }

  Widget _buildDropdownField({
    required String label,
    required String value,
    required List<String> items,
    required ValueChanged<String?> onChanged,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 8.0),
          child: Text(
            label,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              color: Color(0xFF5CA7A4), // Warna label teks
            ),
          ),
        ),
        DropdownButtonFormField<String>(
          value: value,
          decoration: InputDecoration(
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8.0),
              borderSide: const BorderSide(color: Color(0xFF5CA7A4)), // Warna border dropdown
            ),
            enabledBorder: OutlineInputBorder( // Menambahkan enabledBorder
              borderRadius: BorderRadius.circular(8.0),
              borderSide: const BorderSide(color: Color(0xFF5CA7A4)),
            ),
            focusedBorder: OutlineInputBorder( // Menambahkan focusedBorder
              borderRadius: BorderRadius.circular(8.0),
              borderSide: const BorderSide(color: Color(0xFF5CA7A4), width: 2.0),
            ),
            filled: true,
            fillColor: Colors.grey.shade100, // Warna latar belakang dropdown
          ),
          items: items.map((String category) {
            return DropdownMenuItem<String>(
              value: category,
              child: Text(category),
            );
          }).toList(),
          onChanged: onChanged,
        ),
        const SizedBox(height: 16.0),
      ],
    );
  }

  Widget _buildDateField({
    required String label,
    required DateTime date,
    required VoidCallback onTap,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 8.0),
          child: Text(
            label,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              color: Color(0xFF5CA7A4), // Warna label teks
            ),
          ),
        ),
        GestureDetector(
          onTap: onTap,
          child: AbsorbPointer(
            child: TextFormField(
              decoration: InputDecoration(
                hintText: DateFormat('dd MMMM HH:mm').format(date),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                  borderSide: const BorderSide(color: Color(0xFF5CA7A4)), // Warna border date field
                ),
                enabledBorder: OutlineInputBorder( // Menambahkan enabledBorder
                  borderRadius: BorderRadius.circular(8.0),
                  borderSide: const BorderSide(color: Color(0xFF5CA7A4)),
                ),
                focusedBorder: OutlineInputBorder( // Menambahkan focusedBorder
                  borderRadius: BorderRadius.circular(8.0),
                  borderSide: const BorderSide(color: Color(0xFF5CA7A4), width: 2.0),
                ),
                filled: true,
                fillColor: Colors.grey.shade100, // Warna latar belakang date field
              ),
            ),
          ),
        ),
        const SizedBox(height: 16.0),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Tambah Data',
          style: TextStyle(color: Colors.white), // Warna teks judul
        ),
        backgroundColor: const Color(0xFF5CA7A4), // Warna AppBar
        iconTheme: const IconThemeData(color: Colors.white), // Warna ikon back
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _buildInputField(
                label: 'Nama Kegiatan :',
                controller: _nameController,
              ),
              _buildDropdownField(
                label: 'Kategori :',
                value: _selectedCategory,
                items: _categories,
                onChanged: (newValue) {
                  setState(() {
                    _selectedCategory = newValue!;
                  });
                },
              ),
              _buildDateField(
                label: 'Tanggal :',
                date: _selectedDate,
                onTap: () => _selectDate(context),
              ),
              _buildInputField(
                label: 'Deskripsi :',
                controller: _descriptionController,
                isMultiLine: true,
              ),
              const SizedBox(height: 16.0),
              Padding(
                padding: const EdgeInsets.only(bottom: 8.0),
                child: Text(
                  'Dokumentasi :',
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF5CA7A4), // Warna label "Dokumentasi"
                  ),
                ),
              ),
              GestureDetector(
                onTap: _pickImage,
                child: Container(
                  height: 150,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade100, // Warna latar belakang area pick image
                    borderRadius: BorderRadius.circular(8.0),
                    border: Border.all(color: const Color(0xFF5CA7A4)), // Warna border area pick image
                  ),
                  child: _pickedXFile == null
                      ? const Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.camera_alt, size: 50, color: Color(0xFF5CA7A4)), // Warna ikon kamera
                              SizedBox(height: 8.0),
                              Text('Tambahkan Dokumentasi', style: TextStyle(color: Color(0xFF5CA7A4))), // Warna teks
                            ],
                          ),
                        )
                      : kIsWeb && _webImageBytes != null // Jika di web DAN bytes sudah ada
                          ? Image.memory(
                              _webImageBytes!,
                              fit: BoxFit.cover,
                              errorBuilder: (context, error, stackTrace) {
                                return const Center(
                                  child: Text(
                                    'Gagal memuat gambar (Web)',
                                    style: TextStyle(color: Colors.red),
                                  ),
                                );
                              },
                            )
                          : Image.file( // Untuk mobile/desktop
                              File(_pickedXFile!.path),
                              fit: BoxFit.cover,
                              errorBuilder: (context, error, stackTrace) {
                                return const Center(
                                  child: Text(
                                    'Gagal memuat gambar',
                                    style: TextStyle(color: Colors.red),
                                  ),
                                );
                              },
                            ),
                ),
              ),
              const SizedBox(height: 32.0),
              ElevatedButton(
                onPressed: _saveData,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF5CA7A4), // Warna tombol simpan
                  padding: const EdgeInsets.symmetric(vertical: 16.0),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
                child: const Text(
                  'Simpan',
                  style: TextStyle(fontSize: 18.0, color: Colors.white), // Warna teks tombol
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}