import 'package:flutter/material.dart';
import 'package:flutter_application_1/models/activity.dart'; // Adjust path if needed
import 'package:intl/intl.dart'; // For date formatting
import 'dart:io'; // For File

class DetailTaskScreen extends StatelessWidget {
  final Activity activity;

  const DetailTaskScreen({super.key, required this.activity});

  Widget _buildDetailField({required String label, required String value}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 8.0),
          child: Text(
            label,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.teal,
            ),
          ),
        ),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(12.0),
          decoration: BoxDecoration(
            color: Colors.teal.shade50,
            borderRadius: BorderRadius.circular(8.0),
            border: Border.all(color: Colors.teal),
          ),
          child: Text(
            value,
            style: const TextStyle(fontSize: 16.0),
          ),
        ),
        const SizedBox(height: 16.0),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Detail Tugas'),
        backgroundColor: Colors.teal,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _buildDetailField(label: 'Nama Kegiatan :', value: activity.name),
            _buildDetailField(label: 'Kategori :', value: activity.category),
            _buildDetailField(
              label: 'Tanggal :',
              value: DateFormat('dd MMMM yyyy').format(activity.date),
            ),
            _buildDetailField(label: 'Deskripsi :', value: activity.description),
            const SizedBox(height: 16.0),
            Padding(
              padding: const EdgeInsets.only(bottom: 8.0),
              child: Text(
                'Dokumentasi :',
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.teal,
                ),
              ),
            ),
            Container(
              height: 200, // Adjust height as needed
              decoration: BoxDecoration(
                color: Colors.teal.shade50,
                borderRadius: BorderRadius.circular(8.0),
                border: Border.all(color: Colors.teal),
              ),
              child: activity.documentationImagePath != null
                  ? Image.file(
                      File(activity.documentationImagePath!),
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) {
                        return const Center(
                          child: Text(
                            'Gagal memuat gambar',
                            style: TextStyle(color: Colors.red),
                          ),
                        );
                      },
                    )
                  : const Center(
                      child: Text(
                        'Tidak ada dokumentasi',
                        style: TextStyle(color: Colors.grey),
                      ),
                    ),
            ),
            const SizedBox(height: 32.0),
            ElevatedButton(
              onPressed: () {
                // In a real app, you would perform the deletion from your data source
                // and then navigate back.
                // For simplicity, we'll just pop with a true result to indicate deletion.
                Navigator.pop(context, true); // Indicate that the item should be deleted
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red, // Use a distinct color for delete
                padding: const EdgeInsets.symmetric(vertical: 16.0),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
              ),
              child: const Text(
                'Hapus',
                style: TextStyle(fontSize: 18.0, color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }
}